# CropCode procedural models for external rendering

50 plants, the ones the paper's figures draw. Each folder `<figure>/<species>/<plant>_<view>/` holds:

- `true.yml` (sorghum) or `true.xml` (maize): the generator's own file for that plant, copied unchanged.
- `predicted_<model>.yml` / `.xml`: the recipe a CropCode model writes, in the same layout.

Sorghum (EvoEngine spline layout): `stem_length` (m), and per leaf `starting_point` (fraction of the stem),
`length` (m), `roll_angle` and `branching_angle` (degrees), `width` (m). The predicted files carry no
Center/Left/Right Points (those are generator output) and no Seed / Generator Path (they would regenerate the TRUE plant).

Maize (generator XML): `height`, leaf count, and per leaf `distance`, `leafLength`, `leafWidth`, `leafAzimuthDeg`,
`leafAngle`, `droopiness`, `avgCurvature`. `bendAngleDeg` and `bladeLength` are not predicted by the model; they are
filled from linear fits on the true files: bladeLength = 0.8054 x leafLength, bendAngleDeg = -0.000 + -0.9163 x
droopiness (2443 leaves).

`recipes.json` holds every recipe decoded (true and predicted) per figure.

| folder | figure | predicted files |
|---|---|---|
| fig1_teaser | Fig. 1 | row fine-tune on the occluded test row (yaw 0) |
| fig2_stages | Fig. 2 | Stage 2: before / after distillation, photo only; Stage 3: before / after row fine-tuning |
| fig5_rows | Fig. 5 | row fine-tune and isolated control, on the test row |
| supp_rows_galleries | Figs. 28-29 | the same, ten plants per species at yaw 0 and 90 |
