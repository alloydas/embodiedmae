# Sorghum procedural models, XML only

Every sorghum procedural-model file of the shared exports, as XML, in the same folder paths as the original zips:

- `procedural_models_for_viz/<figure>/sorghum/...`: Figs. 1, 2, 3, 5, the sorghum any-to-all supplement figure, the
  supplement row galleries and the E10 figures (`true.xml` = the generator's parameters; `predicted_<model>.xml` = what
  that model writes; E10 real plants have `truth.xml` with the measured values instead of a generator file).
- `fig3_plants_data/sorghum/...`: the Fig. 3 plants; `true.xml` per plant, and per camera
  `viewVV/predicted_from_{image,depth,point_cloud}/procedural_parameters.xml` (distilled generalist, one input) or per
  row yaw `yawYYY/predicted_row_finetune/procedural_parameters.xml`.
- `fig5_plants_data/sorghum/...`: the Fig. 5 plants; `true.xml` and `predicted_{row_finetune,isolated_control}_yaw{000,090}.xml`.

Layout: `<sorghums><sorghum instance_index seed generator_path><parameters stem_length stem_direction .../>
<leaves number="N"><leaf leaf_index starting_point length roll_angle branching_angle width>` with, in the true files,
the generator geometry as `<center_points>`, `<left_points>`, `<right_points>` (`x y z; x y z; ...`, metres).
Angles in degrees, lengths in metres. Each XML is the field-for-field conversion of the EvoEngine `.yml` of the same
name in the full zips; header comments (which model wrote a predicted file) are carried over.
