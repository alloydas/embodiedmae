# CropCode procedural models for external rendering

66 plants, the ones the paper's figures draw. Each folder `<figure>/<species>/<plant>_<view>/` holds:

- `true.yml` (sorghum) or `true.xml` (maize): the generator's own file for that plant, copied unchanged.
- `predicted_<model>.yml` / `.xml`: the recipe a CropCode model writes, in the same layout.

Sorghum (EvoEngine spline layout): `stem_length` (m), and per leaf `starting_point` (fraction of the stem),
`length` (m), `roll_angle` and `branching_angle` (degrees), `width` (m). The predicted files carry no
Center/Left/Right Points (those are generator output) and no Seed / Generator Path (they would regenerate the TRUE plant).

Maize (generator XML): `height`, leaf count, and per leaf `distance`, `leafLength`, `leafWidth`, `leafAzimuthDeg`,
`leafAngle`, `droopiness`, `avgCurvature`. `bendAngleDeg` and `bladeLength` are not predicted by the model; they are
filled from linear fits on the true files: bladeLength = 0.8054 x leafLength, bendAngleDeg = -0.000 + -0.9163 x
droopiness (2443 leaves).

`recipes.json` holds every recipe decoded (true and predicted) per figure.

| folder | figure | predicted files |
|---|---|---|
| fig1_teaser | Fig. 1 | row fine-tune on the occluded test row (yaw 0) |
| fig3_dataset | Fig. 3 | none: the dataset figure shows true plants only (gallery of 6 per species and the crop-row scene plant, with row.json) |
| fig2_stages | Fig. 2 | Stage 2: before / after distillation, photo only; Stage 3: before / after row fine-tuning |
| fig4_any2all_maize / supp_any2all_sorghum | Fig. 4 and its sorghum twin in the supplement | the distilled generalist from each sensor alone: photo, depth, cloud (the figure's parameters row shows the true parameters as input) |
| fig5_rows | Fig. 5 | row fine-tune and isolated control, on the test row |
| supp_rows_galleries | Figs. 28-29 | the same, ten plants per species at yaw 0 and 90 |

## Fig. 3: the plants' data

`fig3_dataset/<species>/<plant>_<role>/` also holds the dataset files the figure is drawn from (as stored in the dataset):

- `gallery_1..5`, `gallery_highlighted` (the 6 gallery plants per species): for each view the figure draws,
  `viewVV_image.png` (photograph), `viewVV_depth.png`, `viewVV_point_cloud_cam.ply` (camera frame) and
  `viewVV_camera_pose.json`. The gallery view is the side view (sorghum camera 4; maize the camera nearest the horizon);
  the highlighted plant also has camera 0 (panel b) and the five cameras of panel c. Sorghum: `point_cloud_complete_world.ply`
  is the whole plant in the generator frame (each view cloud is the same plant moved rigidly into that camera's frame);
  maize view clouds are single-camera captures.
- `row_scene` (panel d, the test row seen broadside, shot 0): `row_image.png`, `row_depth.png`,
  `row_scene_point_cloud_cam.ply` (target + neighbours), `target_image.png`, `target_depth.png`,
  `target_point_cloud_cam.ply` (the target alone, same camera), `camera_pose.json`, `row.json` (the row layout).

## E10 (real plants)

Real plants have no generator file, so each stop folder `<layout>_row<row>_stop<stop>/` holds `truth.json` / `.yml` /
`.xml` (true height, maize leaf count, and for the 3,000-row maize the per-leaf CSV values) and one `predicted_<model>`
file per model the figure shows (all three inputs): `headline_zeroshot`, `synthetic_row_finetune`, `real_row_finetune`.
`recipes_e10.json` collects them. Folders: e10_paper_maize / e10_paper_sorghum (paper E10 figures, first upload),
supp_e10_gallery_maize / _sorghum (supplement E10 galleries), e10_rows3000_examples (the 3,000-row upload examples).

## Both formats

Every model file is given twice, with the same fields and values: sorghum `<name>.yml` (EvoEngine spline layout) and
`<name>.xml` (`<sorghums><sorghum><parameters .../><leaves><leaf .../>`; the true file's generator geometry kept as
`x y z; ...` text); maize `<name>.xml` (generator XML) and `<name>.yml` (`plant: {height, leaves: [...]}`). Header
comments (which model wrote the file, how the unpredicted maize fields were filled) are carried into both.
