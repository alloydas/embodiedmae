# Supplementary material: procedural parameters of every figure that shows plants

Every model file is given as `.yml` and `.xml` with the same fields and values (sorghum: EvoEngine spline layout and its
XML; maize: generator XML and its YAML). `true.*` = the plant's generator file; `predicted_<model>.*` = the procedural
model written by that model (its header comment names the model and the input); real plants (E10) have `truth.*`
(measured height, maize leaf count and per-leaf CSV values) instead of a generator file.

| folder | supplement figure | contents |
|---|---|---|
| `supp_dataset_stats/` | Statistical overview of FieldScan, panel (a) | the eight validation plants per species along the leaf-count range (true only; folder name = plant and its position 1-8) |
| `supp_qual/` | Single-photograph 3D reconstruction | Sorghum_10001 and plant_0003, view 00: true, and the parameters written from the photograph alone by the headline model (before distillation) and the distilled generalist (after) |
| `fig4_any2all_maize/`, `supp_any2all_sorghum/` | Any-to-all cross-modal reconstruction (maize, sorghum) | true, and the distilled generalist from the photograph / depth image / point cloud alone |
| `supp_rows_galleries/` | Maize / sorghum test rows sampled evenly across the error distribution | ten test plants per species at yaw 0 and 90: true, row fine-tuned model and isolated control |
| `e10_paper_maize/`, `e10_paper_sorghum/` | Qualitative results on held-out real maize / sorghum rows | truth, and the pretrained (zero-shot), synthetic-row fine-tuned and real-row fine-tuned models |
| `supp_e10_gallery_maize/`, `supp_e10_gallery_sorghum/` | Held-out real maize rows across error percentiles; all eight held-out real sorghum plants | the same three models per camera stop |

Not included: the two occlusion-ablation figures (training occlusion sources; mixed masking), drawn by separate code
that does not record which plants it shows.
