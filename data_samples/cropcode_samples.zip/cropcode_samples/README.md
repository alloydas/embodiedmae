# CropCode data samples: 10 maize and 10 sorghum test plants, isolated and in crop rows

All plants are from the held-out TEST split. Point clouds are binary little-endian PLY (x, y, z as doubles; open with
Open3D, CloudCompare, MeshLab or `plyfile`). Units are metres.

## isolated/

The plant alone, as in Regimes I and II.

`sorghum/Sorghum_<id>/`, from `Sorghum_15K/test`, view 00:

| File | What it is |
|---|---|
| `<id>_full.ply` | the complete plant cloud at full density (tens of thousands of points; 59,131 for plant 10007) in the generator's world frame |
| `<id>_view00_cam.ply` | the same complete cloud moved rigidly into camera 00's frame; the models subsample 8,196 points from it at load time |
| `rgb_nobg.png` | camera 00's photograph, RGBA with a transparent background |
| `camera_pose.json` | camera 00's pose |
| `<id>_spline.yml` | the procedural parameters (recipe): plant stem plus per-leaf length, roll, branching angle, width, ... |

`maize/plant_<id>/`, from the final maize release (`Maize_1/test`), view 00:

| File | What it is |
|---|---|
| `plant_<id>_view00_cam.ply` | 8,192 points in camera 00's frame. Maize clouds are SINGLE-CAMERA captures (what camera 00 sees), not the complete plant. |
| `rgba.png` | camera 00's photograph, RGBA |
| `camera_pose.json` | camera 00's pose |
| `maize_<id>_spline.xml` | the procedural parameters (recipe), every value an XML attribute |

## rows/

The same plants as the centre plant of a simulated crop row (Regime III). Neighbours are bent around the target by
the contact solver. Two row orientations (yaws): `theta_000` (broadside) and `theta_090` (end-on), shot 0.

`<species>/<plant>/`:

| File | What it is |
|---|---|
| `row.json` | the row layout: neighbours, spacing, yaws |
| `theta_XXX/pointcloud_cam.ply` | the rover's SCENE cloud: target plus neighbours, 24,576 points, camera frame (the model's input) |
| `theta_XXX/gt_pointcloud_cam.ply` | the target (centre) plant alone, 8,192 points, same camera frame (the ground truth) |
| `theta_XXX/rgba.png` | the row photograph the rover takes |
| `theta_XXX/camera_pose.json` | camera pose, plus `near` / `far` and the depth encoding |
| `theta_XXX/*_spline.*` | the target plant's recipe |

The depth images (`depth.png`, `gt_depth.png`) and `gt_rgba.png` (target alone) are left out to keep the archive
small; they are in the full release.

| Plants | IDs |
|---|---|
| Sorghum | 10007, 10011, 10013, 10020, 1003, 10035, 10036, 10040, 10041, 10048 |
| Maize | 0004, 0006, 0007, 0008, 0011, 0036, 0043, 0054, 0056, 0057 |
